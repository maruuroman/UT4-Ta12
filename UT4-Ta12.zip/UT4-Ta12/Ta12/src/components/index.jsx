import { UserProvider } from './components/input'; // Asegúrate de que la ruta sea correcta
import ShowUser from './components/ShowUser'; // Asegúrate de que la ruta sea correcta

const App = () => {
  return (
    <UserProvider>
      <ShowUser />
    </UserProvider>
  );
};

export default App;
